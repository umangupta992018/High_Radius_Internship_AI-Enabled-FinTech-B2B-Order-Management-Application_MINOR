import axios from "axios";
import { useEffect, useState } from "react";
import { withStyles, makeStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';

const StyledTableCell = withStyles((theme) => ({
    head:
    {
        backgroundColor: theme.palette.common.black,
        color: theme.palette.common.white,
    },
    body:
    {
        fontSize: 15,  
    },
}))(TableCell);

const StyledTableRow = withStyles((theme) => ({
    root:
    {
        '&:nth-of-type(odd)':
        {
            backgroundColor: theme.palette.action.hover,
        },
        '&:hover':
        {
            color: '#283A46',
            backgroundColor: "#2079A2",
        },
    },
}))(TableRow);

const useStyles = makeStyles({
    table:
    {
        minWidth: 10,
    },
    container:
    {
        maxWidth: "100%",
        maxHeight: 400
    }
});






const App = () => {
    const classes = useStyles();
    const [product, setProduct] = useState([])
    const [search, setsearch] = useState("")
  
    const getProductData = async () => {
        try {
            const data = await axios.get("http://localhost:8080/Summer_Internship_Backend/DataFetchingServlet/*"
            );
            console.log(data.data)
            setProduct(data.data)
        }
        catch (e) {
            console.log(e)
        }
    }
   

    useEffect(() => {
        getProductData()
    }, [])
    return (
        <div className="App" style={{ height: 400, width: '100%' }}>
            <h1 style={{ color: "white" }} > let have fun</h1>
            <input
                type="text"
                placeholder="search here"
                onChange={e => {
                    setsearch(e.target.value)
                }}
            />
            
            <TableContainer  component={Paper}>
                <Table  className={classes.table} aria-label="customized table">
                    <TableHead display="block" >
                    <TableRow>
                            <StyledTableCell>Customer Name</StyledTableCell>
                            <StyledTableCell >Customer #</StyledTableCell>
                            <StyledTableCell >invoice #</StyledTableCell>
                            <StyledTableCell >Invoice Amount</StyledTableCell>
                            <StyledTableCell >Due Date</StyledTableCell>
                            <StyledTableCell >Predicted Payment Date</StyledTableCell>
                            <StyledTableCell >Predicted Aging Bucket</StyledTableCell>
                            <StyledTableCell >Notes</StyledTableCell>
                        </TableRow>
                    </TableHead>


                    <TableBody style ={{ height: 400, width: '100%' }}>
                        {product.filter(item => {
                            if (search === "") {
                                return item
                            }
                            else if (item.name_customer.toLowerCase().includes(search.toLowerCase())) {
                                return item
                            }
                        })
                            .map((item) => {
                                return (
                                 
                                    <StyledTableRow>
                                    <TableCell component="th" scope="row"> {item.name_customer}</TableCell>
                                    <TableCell component="th" scope="row"> {item.cust_number}</TableCell>
                                    <TableCell component="th" scope="row"> {item.invoice_id}</TableCell>
                                    <TableCell component="th" scope="row"> {item.total_open_amount}</TableCell>
                                    <TableCell component="th" scope="row"> {item.due_in_date}</TableCell>
                                    <TableCell component="th" scope="row">-</TableCell>
                                    <TableCell component="th" scope="row">-</TableCell>
                                    <TableCell component="th" scope="row">-</TableCell>
                                    <TableCell component="th" scope="row">{item.notes}</TableCell>
                                </StyledTableRow>
                                );
                            })}
                    </TableBody>
                </Table>
            </TableContainer>
        </div>
    );
}
export default App;